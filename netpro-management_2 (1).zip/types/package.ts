export interface Package {
  id: number
  name: string
  description: string
  type: string
  price: number
  imageUrl: string
}
